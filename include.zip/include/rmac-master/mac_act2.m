%
% Authored by G. Tolias, 2015. 
%
function [xt, w] = mac_act2(x)

  if ~max(size(x, 1), size(x, 2))
	xt = zeros(size(x, 3), 1, class(x));
	return;
  end

  xt = reshape(max(max(x, [], 1), [], 2), [size(x,3) 1]);

  [Ht,Wd,C] = size(x);

  w = zeros(C,1);
  for i = 1:C
      fm_region = x(:,:,i);

       wt = length(find(fm_region>0))/(size(fm_region,1)*size(fm_region,2));

       w(i) = wt;

  end